/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/index.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/@babel/runtime/helpers/defineProperty.js":
/*!***************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/defineProperty.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

module.exports = _defineProperty;
module.exports["default"] = module.exports, module.exports.__esModule = true;

/***/ }),

/***/ "./node_modules/file-saver/dist/FileSaver.min.js":
/*!*******************************************************!*\
  !*** ./node_modules/file-saver/dist/FileSaver.min.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(global) {var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;(function(a,b){if(true)!(__WEBPACK_AMD_DEFINE_ARRAY__ = [], __WEBPACK_AMD_DEFINE_FACTORY__ = (b),
				__WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ?
				(__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));else {}})(this,function(){"use strict";function b(a,b){return"undefined"==typeof b?b={autoBom:!1}:"object"!=typeof b&&(console.warn("Deprecated: Expected third argument to be a object"),b={autoBom:!b}),b.autoBom&&/^\s*(?:text\/\S*|application\/xml|\S*\/\S*\+xml)\s*;.*charset\s*=\s*utf-8/i.test(a.type)?new Blob(["\uFEFF",a],{type:a.type}):a}function c(a,b,c){var d=new XMLHttpRequest;d.open("GET",a),d.responseType="blob",d.onload=function(){g(d.response,b,c)},d.onerror=function(){console.error("could not download file")},d.send()}function d(a){var b=new XMLHttpRequest;b.open("HEAD",a,!1);try{b.send()}catch(a){}return 200<=b.status&&299>=b.status}function e(a){try{a.dispatchEvent(new MouseEvent("click"))}catch(c){var b=document.createEvent("MouseEvents");b.initMouseEvent("click",!0,!0,window,0,0,0,80,20,!1,!1,!1,!1,0,null),a.dispatchEvent(b)}}var f="object"==typeof window&&window.window===window?window:"object"==typeof self&&self.self===self?self:"object"==typeof global&&global.global===global?global:void 0,a=f.navigator&&/Macintosh/.test(navigator.userAgent)&&/AppleWebKit/.test(navigator.userAgent)&&!/Safari/.test(navigator.userAgent),g=f.saveAs||("object"!=typeof window||window!==f?function(){}:"download"in HTMLAnchorElement.prototype&&!a?function(b,g,h){var i=f.URL||f.webkitURL,j=document.createElement("a");g=g||b.name||"download",j.download=g,j.rel="noopener","string"==typeof b?(j.href=b,j.origin===location.origin?e(j):d(j.href)?c(b,g,h):e(j,j.target="_blank")):(j.href=i.createObjectURL(b),setTimeout(function(){i.revokeObjectURL(j.href)},4E4),setTimeout(function(){e(j)},0))}:"msSaveOrOpenBlob"in navigator?function(f,g,h){if(g=g||f.name||"download","string"!=typeof f)navigator.msSaveOrOpenBlob(b(f,h),g);else if(d(f))c(f,g,h);else{var i=document.createElement("a");i.href=f,i.target="_blank",setTimeout(function(){e(i)})}}:function(b,d,e,g){if(g=g||open("","_blank"),g&&(g.document.title=g.document.body.innerText="downloading..."),"string"==typeof b)return c(b,d,e);var h="application/octet-stream"===b.type,i=/constructor/i.test(f.HTMLElement)||f.safari,j=/CriOS\/[\d]+/.test(navigator.userAgent);if((j||h&&i||a)&&"undefined"!=typeof FileReader){var k=new FileReader;k.onloadend=function(){var a=k.result;a=j?a:a.replace(/^data:[^;]*;/,"data:attachment/file;"),g?g.location.href=a:location=a,g=null},k.readAsDataURL(b)}else{var l=f.URL||f.webkitURL,m=l.createObjectURL(b);g?g.location=m:location.href=m,g=null,setTimeout(function(){l.revokeObjectURL(m)},4E4)}});f.saveAs=g.saveAs=g, true&&(module.exports=g)});

//# sourceMappingURL=FileSaver.min.js.map
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../webpack/buildin/global.js */ "./node_modules/webpack/buildin/global.js")))

/***/ }),

/***/ "./node_modules/webpack/buildin/global.js":
/*!***********************************!*\
  !*** (webpack)/buildin/global.js ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

var g;

// This works in non-strict mode
g = (function() {
	return this;
})();

try {
	// This works if eval is allowed (see CSP)
	g = g || new Function("return this")();
} catch (e) {
	// This works if the window reference is available
	if (typeof window === "object") g = window;
}

// g can still be undefined, but nothing to do about it...
// We return undefined, instead of nothing here, so it's
// easier to handle this case. if(!global) { ...}

module.exports = g;


/***/ }),

/***/ "./src/df_dashboard/component/edit.js":
/*!********************************************!*\
  !*** ./src/df_dashboard/component/edit.js ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/api */ "@wordpress/api");
/* harmony import */ var _wordpress_api__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_api__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _wordpress_api_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/api-fetch */ "@wordpress/api-fetch");
/* harmony import */ var _wordpress_api_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_api_fetch__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @wordpress/data */ "@wordpress/data");
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_wordpress_data__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _wordpress_compose__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @wordpress/compose */ "@wordpress/compose");
/* harmony import */ var _wordpress_compose__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_wordpress_compose__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _wordpress_notices__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @wordpress/notices */ "@wordpress/notices");
/* harmony import */ var _wordpress_notices__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_wordpress_notices__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _partial_general_settings__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./partial/general_settings */ "./src/df_dashboard/component/partial/general_settings.js");
/* harmony import */ var _partial_menu_settings__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./partial/menu_settings */ "./src/df_dashboard/component/partial/menu_settings.js");
/* harmony import */ var _partial_import_export__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./partial/import_export */ "./src/df_dashboard/component/partial/import_export.js");








 // partials





const Notices = () => {
  const notices = Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_4__["useSelect"])(select => select(_wordpress_notices__WEBPACK_IMPORTED_MODULE_7__["store"]).getNotices().filter(notice => notice.type === 'snackbar'), []);
  const {
    removeNotice
  } = Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_4__["useDispatch"])(_wordpress_notices__WEBPACK_IMPORTED_MODULE_7__["store"]);
  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_3__["SnackbarList"], {
    className: "edit-site-notices",
    notices: notices,
    onRemove: removeNotice
  });
};

class Edit extends _wordpress_element__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = {
      isAPILoaded: false,
      active: 'general_settings'
    };
    this._onClick = this._onClick.bind(this);
  }

  componentDidMount() {
    _wordpress_api_fetch__WEBPACK_IMPORTED_MODULE_2___default()({
      path: '/wp/v2/settings'
    }).then(res => {
      this.props.populateSettings(res);
    }).then(() => {
      this.setState({
        isAPILoaded: true
      });
    });
  }

  _onClick(active) {
    this.setState({
      active
    });
  }

  render() {
    const {
      isAPILoaded,
      active
    } = this.state;

    if (!isAPILoaded) {
      return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_3__["Placeholder"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_3__["Spinner"], null));
    }

    return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_3__["Panel"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_partial_general_settings__WEBPACK_IMPORTED_MODULE_8__["default"], {
      active: active,
      activeChange: this._onClick
    })), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_3__["Panel"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_partial_menu_settings__WEBPACK_IMPORTED_MODULE_9__["default"], {
      active: active,
      activeChange: this._onClick
    })), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_3__["Panel"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_partial_import_export__WEBPACK_IMPORTED_MODULE_10__["default"], {
      active: active,
      activeChange: this._onClick
    })), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_3__["Panel"], {
      className: "df-save-button-container"
    }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_3__["Button"], {
      isPrimary: true,
      onClick: () => {
        const settings = new _wordpress_api__WEBPACK_IMPORTED_MODULE_1___default.a.models.Settings(this.props.get_settings.changed);
        settings.save();
        Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_4__["dispatch"])('core/notices').createNotice('success', Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_6__["__"])('Settings Saved', 'divi_flash'), {
          type: 'snackbar',
          isDismissible: true
        });
        setTimeout(() => {
          window.location.reload();
        }, 1500);
      }
    }, Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_6__["__"])('Save Changes', 'divi_flash'))), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
      className: "diviflash-plugin__notices"
    }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(Notices, null)));
  }

}

/* harmony default export */ __webpack_exports__["default"] = (Object(_wordpress_compose__WEBPACK_IMPORTED_MODULE_5__["compose"])([Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_4__["withSelect"])(select => {
  return {
    get_settings: select("diviflash-dashboard/dashboard").getSettings()
  };
}), Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_4__["withDispatch"])(dispatch => {
  return {
    populateSettings: settings => {
      dispatch("diviflash-dashboard/dashboard").populateSettings(settings);
    }
  };
})])(Edit));

/***/ }),

/***/ "./src/df_dashboard/component/partial/general_settings.js":
/*!****************************************************************!*\
  !*** ./src/df_dashboard/component/partial/general_settings.js ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/api */ "@wordpress/api");
/* harmony import */ var _wordpress_api__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_api__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/data */ "@wordpress/data");
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_data__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _wordpress_compose__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @wordpress/compose */ "@wordpress/compose");
/* harmony import */ var _wordpress_compose__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_wordpress_compose__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _utils_row__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../utils/row */ "./src/df_dashboard/component/utils/row.js");
/* harmony import */ var _utils_col__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../utils/col */ "./src/df_dashboard/component/utils/col.js");










class General_Settings extends _wordpress_element__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = {
      df_general_svg_support: false,
      df_general_json_support: false,
      df_general_library_shortcode: true,
      df_general_acf_field_support: false,
      df_general_popup_enable: false,
      attr: {}
    };
  }

  componentDidMount() {
    const attrs = this.props.get_settings;
    this.setState({
      df_general_svg_support: attrs['df_general_svg_support'],
      df_general_json_support: attrs['df_general_json_support'],
      df_general_library_shortcode: attrs['df_general_library_shortcode'],
      df_general_acf_field_support: attrs['df_general_acf_field_support'],
      df_general_popup_enable: attrs['df_general_popup_enable']
    });
  }

  render() {
    const {
      df_general_svg_support,
      df_general_json_support,
      df_general_library_shortcode,
      df_general_acf_field_support,
      df_general_popup_enable
    } = this.state;
    return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__["PanelBody"], {
      title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__["__"])('Extensions', 'divi_flash'),
      opened: this.props.active === 'general_settings' ? true : false,
      onToggle: () => this.props.activeChange('general_settings')
    }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_row__WEBPACK_IMPORTED_MODULE_6__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_col__WEBPACK_IMPORTED_MODULE_7__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("h3", {
      className: "setting-title"
    }, "SVG file upload:")), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_col__WEBPACK_IMPORTED_MODULE_7__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__["ToggleControl"], {
      checked: df_general_svg_support,
      onChange: e => {
        this.setState({
          df_general_svg_support: e
        });
        this.props.updateSettings('df_general_svg_support', e);
      }
    }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("p", {
      className: "setting-description"
    }, "Turn on/off to allow/disallow SVG file upload."))), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_row__WEBPACK_IMPORTED_MODULE_6__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_col__WEBPACK_IMPORTED_MODULE_7__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("h3", {
      className: "setting-title"
    }, "JSON file upload:")), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_col__WEBPACK_IMPORTED_MODULE_7__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__["ToggleControl"], {
      checked: df_general_json_support,
      onChange: e => {
        this.setState({
          df_general_json_support: e
        });
        this.props.updateSettings('df_general_json_support', e);
      }
    }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("p", {
      className: "setting-description"
    }, "Turn on/off to allow/disallow JSON file upload."))), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_row__WEBPACK_IMPORTED_MODULE_6__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_col__WEBPACK_IMPORTED_MODULE_7__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("h3", {
      className: "setting-title"
    }, "Divi Library shortcode:")), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_col__WEBPACK_IMPORTED_MODULE_7__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__["ToggleControl"], {
      checked: df_general_library_shortcode,
      onChange: e => {
        this.setState({
          df_general_library_shortcode: e
        });
        this.props.updateSettings('df_general_library_shortcode', e);
      }
    }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("p", {
      className: "setting-description"
    }, "Turn on/off to enable/disabled divi-library shortcode."))), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_row__WEBPACK_IMPORTED_MODULE_6__["default"], {
      className: "last"
    }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_col__WEBPACK_IMPORTED_MODULE_7__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("h3", {
      className: "setting-title"
    }, "ACF Support:")), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_col__WEBPACK_IMPORTED_MODULE_7__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__["ToggleControl"], {
      checked: df_general_acf_field_support,
      onChange: e => {
        this.setState({
          df_general_acf_field_support: e
        });
        this.props.updateSettings('df_general_acf_field_support', e);
      }
    }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("p", {
      className: "setting-description"
    }, "This setting will allow some modules to pull data from ACF fields to create Grid/Carousel view. Currently supported ACF field types are: ", Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("strong", null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("em", null, "'text', 'number', 'textarea', 'range', 'email', 'url', 'image', 'select', 'date_picker', 'wysiwyg'."))))), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_row__WEBPACK_IMPORTED_MODULE_6__["default"], {
      className: "last"
    }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_col__WEBPACK_IMPORTED_MODULE_7__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("h3", {
      className: "setting-title"
    }, "Popup Enable:")), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_col__WEBPACK_IMPORTED_MODULE_7__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__["ToggleControl"], {
      checked: df_general_popup_enable,
      onChange: e => {
        this.setState({
          df_general_popup_enable: e
        });
        this.props.updateSettings('df_general_popup_enable', e);
      }
    }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("p", {
      className: "setting-description"
    }, "Turn on/off to enable/disabled Popup Exensions")))));
  }

}

/* harmony default export */ __webpack_exports__["default"] = (Object(_wordpress_compose__WEBPACK_IMPORTED_MODULE_4__["compose"])([Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_3__["withSelect"])(select => {
  return {
    get_settings: select("diviflash-dashboard/dashboard").getSettings()
  };
}), Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_3__["withDispatch"])(dispatch => {
  return {
    updateSettings: (index, setting) => {
      dispatch("diviflash-dashboard/dashboard").updateSettings(index, setting);
    }
  };
})])(General_Settings));

/***/ }),

/***/ "./src/df_dashboard/component/partial/import_export.js":
/*!*************************************************************!*\
  !*** ./src/df_dashboard/component/partial/import_export.js ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _wordpress_api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/api */ "@wordpress/api");
/* harmony import */ var _wordpress_api__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_api__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var file_saver__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! file-saver */ "./node_modules/file-saver/dist/FileSaver.min.js");
/* harmony import */ var file_saver__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(file_saver__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @wordpress/data */ "@wordpress/data");
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_wordpress_data__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _wordpress_compose__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @wordpress/compose */ "@wordpress/compose");
/* harmony import */ var _wordpress_compose__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_wordpress_compose__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _utils_row__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../utils/row */ "./src/df_dashboard/component/utils/row.js");
/* harmony import */ var _utils_col__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../utils/col */ "./src/df_dashboard/component/utils/col.js");
/* harmony import */ var _utils_loader__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../utils/loader */ "./src/df_dashboard/component/utils/loader.js");













class Import_Export extends _wordpress_element__WEBPACK_IMPORTED_MODULE_1__["Component"] {
  constructor(props) {
    super(props);

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(this, "handle_export", () => {
      var ajaxurl = window.ajaxurl;

      var _this = this;

      this.setState({
        _exporting: true
      });
      fetch(ajaxurl, {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Cache-Control': 'no-cache'
        },
        body: new URLSearchParams({
          nonce: df_dashboard.nonce,
          action: 'df_export_dashboard_settings'
        })
      }).then(response => {
        return response.json();
      }).then(response => {
        setTimeout(function () {
          _this.setState({
            loading_class: 'loading-finished'
          });

          var fileName = 'df_dashboard_settings.json';
          const file = new Blob([response.data], {
            type: 'application/json'
          });
          Object(file_saver__WEBPACK_IMPORTED_MODULE_3__["saveAs"])(file, fileName);
        }, 500);
        setTimeout(function () {
          _this.setState({
            _exporting: false,
            loading_class: ''
          });
        }, 1000);
      });
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(this, "handle_import", () => {
      this.setState({
        _importing: true
      });
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(this, "process_import", () => {
      const import_file = this.state.importFile;

      var _this = this;

      if (!import_file.context || import_file.context !== "df_settings") {
        _this.setState({
          error: "This is not the right context."
        });

        return;
      } else {
        _this.setState({
          error: ""
        });
      }

      _this.setState({
        _currentlyImporting: true
      });

      fetch(ajaxurl, {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Cache-Control': 'no-cache'
        },
        body: new URLSearchParams({
          nonce: df_dashboard.nonce,
          action: 'df_import_dashboard_settings',
          settings: JSON.stringify(_this.state.importFile)
        })
      }).then(response => {
        return response.json();
      }).then(response => {
        setTimeout(function () {
          _this.setState({
            loading_class: 'loading-finished'
          });
        }, 500);
        setTimeout(function () {
          if (response.data === 'success') {
            location.reload();
          }
        }, 1000);
      });
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(this, "handle_import_close", () => {
      var _this = this;

      _this.setState({
        loading_class: 'loading-finished'
      });

      setTimeout(function () {
        _this.setState({
          _importing: false,
          loading_class: ''
        });
      }, 500);
    });

    this.state = {
      _importing: false,
      _currentlyImporting: false,
      _exporting: false,
      importFile: '',
      error: '',
      loading_class: ''
    };
  }

  render() {
    return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["Fragment"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["PanelBody"], {
      title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_7__["__"])('Import/Export Settings', 'divi_flash'),
      opened: this.props.active === 'import_export' ? true : false,
      onToggle: () => this.props.activeChange('import_export')
    }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_utils_row__WEBPACK_IMPORTED_MODULE_8__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_utils_col__WEBPACK_IMPORTED_MODULE_9__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["Button"], {
      onClick: this.handle_import,
      className: "df-import-export-btn"
    }, "Import Settings"), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["Button"], {
      onClick: this.handle_export,
      className: "df-import-export-btn"
    }, "Export Settings"), this.state._exporting ? Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])("div", {
      className: "export-overlay " + this.state.loading_class
    }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])("div", {
      className: "export-loader"
    }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])("h4", null, "Exporting settings..."), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_utils_loader__WEBPACK_IMPORTED_MODULE_10__["default"], null))) : ''))), this.state._importing ? Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])("div", {
      className: "import-overlay " + this.state.loading_class
    }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])("div", {
      className: "import-file-box"
    }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])("span", {
      className: "upload-box-title"
    }, "Import Settings"), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])("span", {
      className: "close-button",
      onClick: this.handle_import_close
    }, "X"), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])("div", {
      className: "choose-file"
    }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["FormFileUpload"], {
      accept: "json/*",
      onChange: e => {
        const file = e.target.files[0];
        const reader = new FileReader();

        reader.onload = event => {
          this.setState({
            importFile: JSON.parse(event.target.result)
          });
        };

        reader.readAsText(file);
      }
    })), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])("button", {
      className: "import-button",
      onClick: this.process_import
    }, "Import"), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])("div", {
      className: "df-error"
    }, this.state.error), this.state._currentlyImporting ? Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_utils_loader__WEBPACK_IMPORTED_MODULE_10__["default"], null) : '')) : '');
  }

}

/* harmony default export */ __webpack_exports__["default"] = (Import_Export);

/***/ }),

/***/ "./src/df_dashboard/component/partial/menu_settings.js":
/*!*************************************************************!*\
  !*** ./src/df_dashboard/component/partial/menu_settings.js ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/api */ "@wordpress/api");
/* harmony import */ var _wordpress_api__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_api__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/data */ "@wordpress/data");
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_data__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _wordpress_compose__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @wordpress/compose */ "@wordpress/compose");
/* harmony import */ var _wordpress_compose__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_wordpress_compose__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _utils_row__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../utils/row */ "./src/df_dashboard/component/utils/row.js");
/* harmony import */ var _utils_col__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../utils/col */ "./src/df_dashboard/component/utils/col.js");










class Menu_Settings extends _wordpress_element__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = {
      df_menu_bottom_line: false,
      df_menu_bottom_line_color: "#333333",
      df_menu_bottom_line_height: 1,
      df_menu_line_width: 'full',
      df_menu_line_animation: 'no_animation',
      df_menu_hide_bottom_border: false,
      df_menu_item_distance: 22,
      df_menu_bottom_line_distance: 0,
      df_menu_bottom_line_distance_fixed: 0
    };
  }

  componentDidMount() {
    const attributes = this.props.get_settings;
    this.setState({
      df_menu_bottom_line: attributes['df_menu_bottom_line'],
      df_menu_bottom_line_color: attributes['df_menu_bottom_line_color'],
      df_menu_bottom_line_height: attributes['df_menu_bottom_line_height'],
      df_menu_line_width: attributes['df_menu_line_width'],
      df_menu_line_animation: attributes['df_menu_line_animation'],
      df_menu_hide_bottom_border: attributes['df_menu_hide_bottom_border'],
      df_menu_item_distance: attributes['df_menu_item_distance'],
      df_menu_bottom_line_distance: attributes['df_menu_bottom_line_distance'],
      df_menu_bottom_line_distance_fixed: attributes['df_menu_bottom_line_distance_fixed']
    });
  }

  render() {
    const {
      df_menu_bottom_line,
      df_menu_bottom_line_color,
      df_menu_bottom_line_height,
      df_menu_line_width,
      df_menu_line_animation,
      df_menu_hide_bottom_border,
      df_menu_item_distance,
      df_menu_bottom_line_distance,
      df_menu_bottom_line_distance_fixed
    } = this.state;
    return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__["PanelBody"], {
      title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__["__"])('Menu Extension Settings', 'divi_flash'),
      opened: this.props.active === 'menu_settings' ? true : false,
      onToggle: () => this.props.activeChange('menu_settings')
    }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_row__WEBPACK_IMPORTED_MODULE_6__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_col__WEBPACK_IMPORTED_MODULE_7__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("h3", {
      className: "setting-title"
    }, "Menu bottom line:")), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_col__WEBPACK_IMPORTED_MODULE_7__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__["ToggleControl"], {
      checked: df_menu_bottom_line,
      onChange: df_menu_bottom_line => {
        this.setState({
          df_menu_bottom_line
        });
        this.props.updateSettings('df_menu_bottom_line', df_menu_bottom_line);
      }
    }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("p", {
      className: "setting-description"
    }, "Turn on/off divi menu bottom line effect."))), df_menu_bottom_line ? Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_row__WEBPACK_IMPORTED_MODULE_6__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_col__WEBPACK_IMPORTED_MODULE_7__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("h3", {
      className: "setting-title"
    }, "Bottom line color:")), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_col__WEBPACK_IMPORTED_MODULE_7__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__["ColorPicker"], {
      color: df_menu_bottom_line_color,
      onChange: df_menu_bottom_line_color => {
        this.setState({
          df_menu_bottom_line_color: df_menu_bottom_line_color.hex
        });
        this.props.updateSettings('df_menu_bottom_line_color', df_menu_bottom_line_color.hex);
      },
      enableAlpha: true,
      defaultValue: "#000"
    }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("p", {
      className: "setting-description"
    }, "Select bottom line color."))) : null, df_menu_bottom_line ? Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_row__WEBPACK_IMPORTED_MODULE_6__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_col__WEBPACK_IMPORTED_MODULE_7__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("h3", {
      className: "setting-title"
    }, "Bottom line weight:")), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_col__WEBPACK_IMPORTED_MODULE_7__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__["RangeControl"], {
      label: "Line Weight",
      value: df_menu_bottom_line_height,
      onChange: df_menu_bottom_line_height => {
        this.setState({
          df_menu_bottom_line_height: df_menu_bottom_line_height
        });
        this.props.updateSettings('df_menu_bottom_line_height', df_menu_bottom_line_height);
      },
      min: 1,
      max: 10
    }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("p", {
      className: "setting-description"
    }, "Bottom line height."))) : null, df_menu_bottom_line ? Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_row__WEBPACK_IMPORTED_MODULE_6__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_col__WEBPACK_IMPORTED_MODULE_7__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("h3", {
      className: "setting-title"
    }, "Bottom line distance:")), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_col__WEBPACK_IMPORTED_MODULE_7__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__["RangeControl"], {
      label: "Line distance",
      value: df_menu_bottom_line_distance,
      onChange: df_menu_bottom_line_distance => {
        this.setState({
          df_menu_bottom_line_distance
        });
        this.props.updateSettings('df_menu_bottom_line_distance', df_menu_bottom_line_distance);
      },
      min: -50,
      max: 50
    }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("p", {
      className: "setting-description"
    }, "Change the bottom line distance."))) : null, df_menu_bottom_line ? Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_row__WEBPACK_IMPORTED_MODULE_6__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_col__WEBPACK_IMPORTED_MODULE_7__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("h3", {
      className: "setting-title"
    }, "Bottom line distance for fixed nav:")), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_col__WEBPACK_IMPORTED_MODULE_7__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__["RangeControl"], {
      label: "Line distance",
      value: df_menu_bottom_line_distance_fixed,
      onChange: df_menu_bottom_line_distance_fixed => {
        this.setState({
          df_menu_bottom_line_distance_fixed
        });
        this.props.updateSettings('df_menu_bottom_line_distance_fixed', df_menu_bottom_line_distance_fixed);
      },
      min: -50,
      max: 50
    }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("p", {
      className: "setting-description"
    }, "Change the bottom line distance for the fixed nav."))) : null, df_menu_bottom_line ? Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_row__WEBPACK_IMPORTED_MODULE_6__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_col__WEBPACK_IMPORTED_MODULE_7__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("h3", {
      className: "setting-title"
    }, "Line width:")), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_col__WEBPACK_IMPORTED_MODULE_7__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__["SelectControl"], {
      label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__["__"])('Select line width:'),
      value: df_menu_line_width,
      onChange: df_menu_line_width => {
        this.setState({
          df_menu_line_width
        });
        this.props.updateSettings('df_menu_line_width', df_menu_line_width);
      },
      options: [{
        value: null,
        label: 'Select a option',
        disabled: true
      }, {
        value: 'full',
        label: 'Full'
      }, {
        value: 'half_left',
        label: 'Half left'
      }, {
        value: 'half_right',
        label: 'Half right'
      }]
    }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("p", {
      className: "setting-description"
    }, "Select line width from the options."))) : null, df_menu_bottom_line ? Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_row__WEBPACK_IMPORTED_MODULE_6__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_col__WEBPACK_IMPORTED_MODULE_7__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("h3", {
      className: "setting-title"
    }, "Line hover animation:")), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_col__WEBPACK_IMPORTED_MODULE_7__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__["SelectControl"], {
      label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__["__"])('Select animation:'),
      value: df_menu_line_animation,
      onChange: df_menu_line_animation => {
        this.setState({
          df_menu_line_animation
        });
        this.props.updateSettings('df_menu_line_animation', df_menu_line_animation);
      },
      options: [{
        value: null,
        label: 'Select animation type',
        disabled: true
      }, {
        value: 'left',
        label: 'From Left'
      }, {
        value: 'right',
        label: 'From Right'
      }, {
        value: 'center',
        label: 'From Center'
      }]
    }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("p", {
      className: "setting-description"
    }, "Select from the animation from the options."))) : null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_row__WEBPACK_IMPORTED_MODULE_6__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_col__WEBPACK_IMPORTED_MODULE_7__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("h3", {
      className: "setting-title"
    }, "Hide menu bottom border:")), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_col__WEBPACK_IMPORTED_MODULE_7__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__["ToggleControl"], {
      checked: df_menu_hide_bottom_border,
      onChange: df_menu_hide_bottom_border => {
        this.setState({
          df_menu_hide_bottom_border
        });
        this.props.updateSettings('df_menu_hide_bottom_border', df_menu_hide_bottom_border);
      }
    }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("p", {
      className: "setting-description"
    }, "Hide the bottom border from naviagation bar by", Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("br", null), "turning on the setting."))), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_row__WEBPACK_IMPORTED_MODULE_6__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_col__WEBPACK_IMPORTED_MODULE_7__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("h3", {
      className: "setting-title"
    }, "Menu item space between (px):")), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_utils_col__WEBPACK_IMPORTED_MODULE_7__["default"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__["RangeControl"], {
      label: "Space between",
      value: df_menu_item_distance,
      onChange: df_menu_item_distance => {
        this.setState({
          df_menu_item_distance
        });
        this.props.updateSettings('df_menu_item_distance', df_menu_item_distance);
      },
      min: 1,
      max: 100
    }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("p", {
      className: "setting-description"
    }, "Increase/decrease space between each menu item.")))));
  }

}

/* harmony default export */ __webpack_exports__["default"] = (Object(_wordpress_compose__WEBPACK_IMPORTED_MODULE_4__["compose"])([Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_3__["withSelect"])(select => {
  return {
    get_settings: select("diviflash-dashboard/dashboard").getSettings()
  };
}), Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_3__["withDispatch"])(dispatch => {
  return {
    updateSettings: (index, setting) => {
      dispatch("diviflash-dashboard/dashboard").updateSettings(index, setting);
    }
  };
})])(Menu_Settings));

/***/ }),

/***/ "./src/df_dashboard/component/sidebar.js":
/*!***********************************************!*\
  !*** ./src/df_dashboard/component/sidebar.js ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__);




class Sidebar extends _wordpress_element__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  render() {
    return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
      className: "df-sidebar-box df-doc-bar"
    }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("h3", {
      className: "sidebar-title"
    }, "Getting Started? Check help and docs"), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("p", null, "Need more details? Please check our full documentation for detailed information on how to use Diviflash."), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("a", {
      target: "_blank",
      href: "https://www.diviflash.com/docs/"
    }, "Read the docs")), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
      className: "df-sidebar-box df-doc-bar"
    }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("h3", {
      className: "sidebar-title"
    }, "Need Help?"), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("p", null, "Didn't get what you need? Don't worry. Our dedicated support team will help you with anything."), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("a", {
      target: "_blank",
      href: "https://diviflash.freshdesk.com/support/home"
    }, "Contact Support")));
  }

}

/* harmony default export */ __webpack_exports__["default"] = (Sidebar);

/***/ }),

/***/ "./src/df_dashboard/component/utils/col.js":
/*!*************************************************!*\
  !*** ./src/df_dashboard/component/utils/col.js ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);


const Df_Setting_Col = props => {
  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
    className: "df-setting-col"
  }, props.children);
};

/* harmony default export */ __webpack_exports__["default"] = (Df_Setting_Col);

/***/ }),

/***/ "./src/df_dashboard/component/utils/loader.js":
/*!****************************************************!*\
  !*** ./src/df_dashboard/component/utils/loader.js ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);



class Loader extends _wordpress_element__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  render() {
    return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
      id: "fountainG"
    }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
      id: "fountainG_1",
      className: "fountainG"
    }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
      id: "fountainG_2",
      className: "fountainG"
    }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
      id: "fountainG_3",
      className: "fountainG"
    }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
      id: "fountainG_4",
      className: "fountainG"
    }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
      id: "fountainG_5",
      className: "fountainG"
    }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
      id: "fountainG_6",
      className: "fountainG"
    }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
      id: "fountainG_7",
      className: "fountainG"
    }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
      id: "fountainG_8",
      className: "fountainG"
    }));
  }

}

/* harmony default export */ __webpack_exports__["default"] = (Loader);

/***/ }),

/***/ "./src/df_dashboard/component/utils/row.js":
/*!*************************************************!*\
  !*** ./src/df_dashboard/component/utils/row.js ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);


const Df_Setting_Row = props => {
  const _classes = props.className ? `df-setting-row ${props.className}` : `df-setting-row`;

  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
    className: _classes
  }, props.children);
};

/* harmony default export */ __webpack_exports__["default"] = (Df_Setting_Row);

/***/ }),

/***/ "./src/df_dashboard/df_dashboard.scss":
/*!********************************************!*\
  !*** ./src/df_dashboard/df_dashboard.scss ***!
  \********************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./src/df_dashboard/index.js":
/*!***********************************!*\
  !*** ./src/df_dashboard/index.js ***!
  \***********************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _df_dashboard_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./df_dashboard.scss */ "./src/df_dashboard/df_dashboard.scss");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _component_edit__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./component/edit */ "./src/df_dashboard/component/edit.js");
/* harmony import */ var _component_sidebar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./component/sidebar */ "./src/df_dashboard/component/sidebar.js");








class App extends _wordpress_element__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor() {
    super(...arguments);
  }

  render() {
    return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
      className: "diviflash-plugin__header"
    }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
      className: "diviflash-plugin__container"
    }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
      className: "diviflash-plugin__title"
    }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("h1", null, Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('DiviFlash Plugin Settings', 'divi_flash'))))), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
      className: "diviflash-plugin__main"
    }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
      className: "df-settings-content-area"
    }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_component_edit__WEBPACK_IMPORTED_MODULE_4__["default"], null)), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
      className: "df-settings-sidebar-area"
    }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_component_sidebar__WEBPACK_IMPORTED_MODULE_5__["default"], null))));
  }

}

document.addEventListener('DOMContentLoaded', () => {
  const htmlOutput = document.getElementById('diviflash-plugin-dashboard');

  if (htmlOutput) {
    Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["render"])(Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(App, null), htmlOutput);
  }
});

/***/ }),

/***/ "./src/index.js":
/*!**********************!*\
  !*** ./src/index.js ***!
  \**********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _df_dashboard_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./df_dashboard/index.js */ "./src/df_dashboard/index.js");
/* harmony import */ var _store_dashboard_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./store/dashboard.js */ "./src/store/dashboard.js");



/***/ }),

/***/ "./src/store/dashboard.js":
/*!********************************!*\
  !*** ./src/store/dashboard.js ***!
  \********************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/api */ "@wordpress/api");
/* harmony import */ var _wordpress_api__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_api__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/data */ "@wordpress/data");
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_data__WEBPACK_IMPORTED_MODULE_1__);


const DEFAULT_STATE = {};
const actions = {
  populateSettings(settings) {
    return {
      type: "POPULATE_SETTINGS",
      settings
    };
  },

  fetchSettings() {
    return {
      type: "FETCH_SETTINGS"
    };
  },

  updateSettings(index, setting) {
    return {
      type: "UPDATE_SETTINGS",
      index,
      setting
    };
  }

};

const reducer = (state = DEFAULT_STATE, action) => {
  switch (action.type) {
    case "FETCH_SETTINGS":
      return { ...state
      };

    case "POPULATE_SETTINGS":
      const settings = action.settings;
      return { ...settings
      };

    case "UPDATE_SETTINGS":
      let state_copy = { ...state
      };
      if (!state_copy.changed) state_copy.changed = {};
      state_copy.changed[action.index] = action.setting;
      return state_copy;

    default:
      return state;
  }
};

const selectors = {
  getSettings(state) {
    return state;
  },

  fetchSettings() {
    const settings = new _wordpress_api__WEBPACK_IMPORTED_MODULE_0___default.a.models.Settings();
    settings.fetch().then(response => {
      return response;
    });
    return settings;
  }

};
const store = Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_1__["createReduxStore"])('diviflash-dashboard/dashboard', {
  reducer,
  selectors,
  actions,
  controls: {
    FETCH_SETTINGS() {
      const settings = new _wordpress_api__WEBPACK_IMPORTED_MODULE_0___default.a.models.Settings();
      settings.fetch().then(response => {
        return response;
      });
      return settings;
    }

  },
  resolvers: {// *getSettings() {
    //     const settings = yield actions.fetchSettings();
    //     return actions.populateSettings(settings);
    // }
  }
});
Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_1__["register"])(store);

/***/ }),

/***/ "@wordpress/api":
/*!*****************************!*\
  !*** external ["wp","api"] ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = window["wp"]["api"]; }());

/***/ }),

/***/ "@wordpress/api-fetch":
/*!**********************************!*\
  !*** external ["wp","apiFetch"] ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = window["wp"]["apiFetch"]; }());

/***/ }),

/***/ "@wordpress/components":
/*!************************************!*\
  !*** external ["wp","components"] ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = window["wp"]["components"]; }());

/***/ }),

/***/ "@wordpress/compose":
/*!*********************************!*\
  !*** external ["wp","compose"] ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = window["wp"]["compose"]; }());

/***/ }),

/***/ "@wordpress/data":
/*!******************************!*\
  !*** external ["wp","data"] ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = window["wp"]["data"]; }());

/***/ }),

/***/ "@wordpress/element":
/*!*********************************!*\
  !*** external ["wp","element"] ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = window["wp"]["element"]; }());

/***/ }),

/***/ "@wordpress/i18n":
/*!******************************!*\
  !*** external ["wp","i18n"] ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = window["wp"]["i18n"]; }());

/***/ }),

/***/ "@wordpress/notices":
/*!*********************************!*\
  !*** external ["wp","notices"] ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = window["wp"]["notices"]; }());

/***/ })

/******/ });
//# sourceMappingURL=index.js.map