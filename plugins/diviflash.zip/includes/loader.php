<?php
/**
 * Load utility functions and classes
 * for the Visual builder
 */

$module_obj = new Diviflash_Module_Manage();
$module_obj->include_module();
