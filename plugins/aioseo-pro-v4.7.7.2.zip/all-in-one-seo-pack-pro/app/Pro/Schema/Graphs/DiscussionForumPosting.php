<?php
namespace AIOSEO\Plugin\Pro\Schema\Graphs;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AIOSEO\Plugin\Common\Schema\Graphs as CommonGraphs;

/**
 * DiscussionForumPosting graph class.
 *
 * @since 4.7.6
 */
class DiscussionForumPosting extends CommonGraphs\Graph {
	/**
	 * The activity single page data.
	 *
	 * @since 4.7.6
	 *
	 * @var array
	 */
	public $activity = [];

	/**
	 * Returns the graph data.
	 *
	 * @since 4.7.6
	 *
	 * @param  object|null $graphData The graph data.
	 * @return array                  The parsed graph data.
	 */
	public function get( $graphData = null ) {
		$this->setActivity();

		if ( empty( $this->activity ) ) {
			return [];
		}

		return [
			'@type'         => 'DiscussionForumPosting',
			'id'            => aioseo()->schema->context['url'] . '#discussion-forum-posting',
			'headline'      => ! empty( $graphData->properties->headline ) ? $graphData->properties->headline : get_the_title(),
			'text'          => ! empty( $graphData->properties->text ) ? $graphData->properties->text : $this->activity['content_rendered'] ?? '',
			'url'           => aioseo()->schema->context['url'],
			'datePublished' => ! empty( $graphData->properties->datePublished )
				? mysql2date( DATE_W3C, $graphData->properties->datePublished, false )
				: mysql2date( DATE_W3C, $this->activity['date_recorded'], false ) ?? '',
			'comment'       => $this->generateCommentsGraphData( $graphData ),
			'author'        => [
				'@type' => 'Person',
				'name'  => ! empty( $graphData->properties->author ) ? $graphData->properties->author : $this->activity['user_fullname'] ?? '',
			],
		];
	}

	/**
	 * Generate comments graph data.
	 *
	 * @since 4.7.6
	 *
	 * @param  object|null $graphData The graph data.
	 * @return array                  The comments data.
	 */
	private function generateCommentsGraphData( $graphData = null ) {
		$activityComments = ! empty( $graphData->properties->comments )
			? $graphData->properties->comments
			: $this->activity['children'] ?? [];

		if ( empty( $activityComments ) ) {
			return [];
		}

		return $this->getActivityCommentsRecursively( $activityComments );
	}

	/**
	 * Sets the activity data.
	 *
	 * @since 4.7.6
	 *
	 * @return void
	 */
	private function setActivity() {
		$activity = aioseo()->standalone->buddyPress->component->activity ?? [];
		if ( empty( [ $activity['id'] ] ) ) {
			return;
		}

		$this->activity = $activity;
	}

	/**
	 * Get activity comments graph data.
	 *
	 * @since 4.7.6
	 *
	 * @param  array $comments The comments.
	 * @return array           The formatted comments.
	 */
	private function getActivityCommentsRecursively( $comments ) {
		$data = [];
		foreach ( $comments as $comment ) {
			$commentData = $this->getCommentSingleGraphData( $comment );

			// Process any children comments recursively.
			if ( ! empty( $comment->children ) ) {
				$commentData['comment'] = $this->getActivityCommentsRecursively( $comment->children ?? [] );
			}

			$data[] = $commentData;
		}

		return $data;
	}

	/**
	 * Get comment single graph data.
	 *
	 * @param object $comment The comment object.
	 * @return array          The comment graph data.
	 */
	private function getCommentSingleGraphData( $comment ) {
		return [
			'@type'         => 'Comment',
			'text'          => $comment->content,
			'datePublished' => mysql2date( DATE_W3C, $comment->date_recorded, false ),
			'author'        => [
				'@type' => 'Person',
				'name'  => $comment->user_fullname,
			],
		];
	}
}