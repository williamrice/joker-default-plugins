<?php
$wp_customize->add_setting( 'dtb_customize_title_overlay', array(
	'default' => '',
	'transport' => 'refresh',
	'sanitize_callback' => 'wp_filter_nohtml_kses'
));
$wp_customize->add_control( new Toolbox_Toggle( $wp_customize, 'dtb_customize_title_overlay', array(
	'label' => __( 'Builder Overlays', 'divi-toolbox' ),
	'section' => 'dtb_general'
)));
$wp_customize->add_setting( 'dtb_customize_overlay_bg', array(
	'default' => 'rgba(255,255,255,0.8);',
	'type' => 'option', 
	'capability' => 'edit_theme_options',
	'sanitize_callback' => 'et_sanitize_alpha_color'
));
$wp_customize->add_control( new ET_Divi_Customize_Color_Alpha_Control( $wp_customize, 'dtb_customize_overlay_bg', array(
	'label' => __('Overlay Background Color', 'divi-toolbox'),
	'section' => 'dtb_general',
	'settings' => 'dtb_customize_overlay_bg'
)));

$wp_customize->add_setting( 'dtb_customize_t_overlay_button', array(
	'default' => '',
	'transport' => 'refresh',
	'sanitize_callback' => 'wp_filter_nohtml_kses'
));
$wp_customize->add_control( new Toolbox_Descriptions( $wp_customize, 'dtb_customize_t_overlay_button', array(
	'label' => __( 'Close Button & Icon', 'divi-toolbox' ),
	'section' => 'dtb_general'
)));

$wp_customize->add_setting( 'dtb_customize_overlay_close', array(
	'default' => '#000000',
	'type' => 'option', 
	'capability' => 'edit_theme_options',
	'sanitize_callback' => 'et_sanitize_alpha_color'
));
$wp_customize->add_control( new ET_Divi_Customize_Color_Alpha_Control( $wp_customize, 'dtb_customize_overlay_close', array(
	'label' => __('Icon Color', 'divi-toolbox'),
	'section' => 'dtb_general',
	'settings' => 'dtb_customize_overlay_close'
)));
$wp_customize->add_setting( 'dtb_customize_overlay_close_bg', array(
	'default' => '#fff;',
	'type' => 'option', 
	'capability' => 'edit_theme_options',
	'sanitize_callback' => 'et_sanitize_alpha_color'
));
$wp_customize->add_control( new ET_Divi_Customize_Color_Alpha_Control( $wp_customize, 'dtb_customize_overlay_close_bg', array(
	'label' => __('Button Background Color', 'divi-toolbox'),
	'section' => 'dtb_general',
	'settings' => 'dtb_customize_overlay_close_bg'
)));
$wp_customize->add_setting( 'dtb_customize_overlay_close_hover', array(
	'default' => '#ffffff;',
	'type' => 'option', 
	'capability' => 'edit_theme_options',
	'sanitize_callback' => 'et_sanitize_alpha_color'
));
$wp_customize->add_control( new ET_Divi_Customize_Color_Alpha_Control( $wp_customize, 'dtb_customize_overlay_close_hover', array(
	'label' => __('Icon Color on Hover', 'divi-toolbox'),
	'section' => 'dtb_general',
	'settings' => 'dtb_customize_overlay_close_hover'
)));
$wp_customize->add_setting( 'dtb_customize_overlay_close_bg_hover', array(
	'default' => '#000000;',
	'type' => 'option', 
	'capability' => 'edit_theme_options',
	'sanitize_callback' => 'et_sanitize_alpha_color'
));
$wp_customize->add_control( new ET_Divi_Customize_Color_Alpha_Control( $wp_customize, 'dtb_customize_overlay_close_bg_hover', array(
	'label' => __('Button Background Color on Hover', 'divi-toolbox'),
	'section' => 'dtb_general',
	'settings' => 'dtb_customize_overlay_close_bg_hover'
)));


$wp_customize->add_setting('dtb_customize_overlay_icon_size', array(
	'default' => '40',
	'type' => 'option',
	'capability' => 'edit_theme_options',
	'sanitize_callback' => 'et_sanitize_int_number'
));

$wp_customize->add_control( new ET_Divi_Range_Option ( $wp_customize, 'dtb_customize_overlay_icon_size', array(
	'label' => __('Button Size', 'divi-toolbox'),
	'section' => 'dtb_general',
	'type'        => 'range',
	'input_attrs' => array(
		'min'  => 20,
		'max'  => 100,
		'step' => 1
	)
)));


$wp_customize->add_setting('dtb_customize_overlay_button_border', array(
	'default' => '3',
	'type' => 'option',
	'capability' => 'edit_theme_options',
	'sanitize_callback' => 'et_sanitize_int_number'
));

$wp_customize->add_control( new ET_Divi_Range_Option ( $wp_customize, 'dtb_customize_overlay_button_border', array(
	'label' => __('Button Border Radius', 'divi-toolbox'),
	'section' => 'dtb_general',
	'type'        => 'range',
	'input_attrs' => array(
		'min'  => 0,
		'max'  => 50,
		'step' => 1
	)
)));

$wp_customize->add_setting('dtb_customize_overlay_button_top', array(
	'default' => '15',
	'type' => 'option',
	'capability' => 'edit_theme_options',
	'sanitize_callback' => 'et_sanitize_int_number'
));

$wp_customize->add_control( new ET_Divi_Range_Option ( $wp_customize, 'dtb_customize_overlay_button_top', array(
	'label' => __('Button Top Offset', 'divi-toolbox'),
	'section' => 'dtb_general',
	'type'        => 'range',
	'input_attrs' => array(
		'min'  => 0,
		'max'  => 50,
		'step' => 1
	)
)));
$wp_customize->add_setting('dtb_customize_overlay_button_right', array(
	'default' => '15',
	'type' => 'option',
	'capability' => 'edit_theme_options',
	'sanitize_callback' => 'et_sanitize_int_number'
));

$wp_customize->add_control( new ET_Divi_Range_Option ( $wp_customize, 'dtb_customize_overlay_button_right', array(
	'label' => __('Button Right Offset', 'divi-toolbox'),
	'section' => 'dtb_general',
	'type'        => 'range',
	'input_attrs' => array(
		'min'  => 0,
		'max'  => 50,
		'step' => 1
	)
)));

$wp_customize->add_setting('dtb_customize_overlay_icon_thick', array(
	'default' => '2',
	'type' => 'option',
	'capability' => 'edit_theme_options',
	'sanitize_callback' => 'et_sanitize_int_number'
));

$wp_customize->add_control( new ET_Divi_Range_Option ( $wp_customize, 'dtb_customize_overlay_icon_thick', array(
	'label' => __('Icon Thickness', 'divi-toolbox'),
	'section' => 'dtb_general',
	'type'        => 'range',
	'input_attrs' => array(
		'min'  => 1,
		'max'  => 20,
		'step' => 1
	)
)));


$wp_customize->add_setting('dtb_customize_overlay_icon_border', array(
	'default' => '2',
	'type' => 'option',
	'capability' => 'edit_theme_options',
	'sanitize_callback' => 'et_sanitize_int_number'
));

$wp_customize->add_control( new ET_Divi_Range_Option ( $wp_customize, 'dtb_customize_overlay_icon_border', array(
	'label' => __('Icon Border Radius', 'divi-toolbox'),
	'section' => 'dtb_general',
	'type'        => 'range',
	'input_attrs' => array(
		'min'  => 0,
		'max'  => 10,
		'step' => 1
	)
)));