<?php
	
$wp_customize->add_setting( 'dtb_customize_title_ts_particles', array(
	'default' => '',
	'transport' => 'refresh',
	'sanitize_callback' => 'wp_filter_nohtml_kses'
));
$wp_customize->add_control( new Toolbox_Toggle( $wp_customize, 'dtb_customize_title_ts_particles', array(
	'label' => __( 'Moving Particles Background 2.0', 'divi-toolbox' ),
	'section' => 'dtb_general'
)));	
	
// #1

$wp_customize->add_setting( 'dtb_customize_title_ts_particles1_desc', array(
	'default' => '',
	'transport' => 'refresh',
	'sanitize_callback' => 'wp_filter_nohtml_kses'
));
$wp_customize->add_control( new Toolbox_Descriptions( $wp_customize, 'dtb_customize_title_ts_particles1_desc', array(
	'description'  => esc_html__( 'The first set of controls applies to any element with the custom CSS ID of moving-bg1 or the page container (if enabled). The second set of controls applies to an element with CSS ID of moving-bg2' ),
	'section' => 'dtb_general'
)));
$wp_customize->add_setting( 'dtb_customize_title_ts_particles1', array(
	'default' => '',
	'transport' => 'refresh',
	'sanitize_callback' => 'wp_filter_nohtml_kses'
));
$wp_customize->add_control( new Toolbox_Descriptions( $wp_customize, 'dtb_customize_title_ts_particles1', array(
	'label' => __( 'Particle Background #1', 'divi-toolbox' ),
	'section' => 'dtb_general'
)));
$wp_customize->add_setting( 'dtb_customize_ts_particles1_number', array(
	'default' => 80,
	'type'			  => 'option',
	'capability'    => 'edit_theme_options',
	'sanitize_callback' => 'et_sanitize_int_number'
));
$wp_customize->add_control( new ET_Divi_Range_Option ( $wp_customize, 'dtb_customize_ts_particles1_number', array(
	'label' => __('Number of Particles', 'divi-toolbox'),
	'section' => 'dtb_general',
	'type'			=> 'range',
	'input_attrs' => array(
		'min'  => 0,
		'max'  => 300,
		'step' => 1
	)
)));
$wp_customize->add_setting( 'dtb_customize_ts_particles1_color1', array(
	'default' => '#000000',
	'type' => 'option',
	'sanitize_callback' => 'et_sanitize_alpha_color',
	'capability' => 'edit_theme_options'
));
$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'dtb_customize_ts_particles1_color1', array(
	'label' => __('Particles Color #1', 'divi-toolbox'),
	'section' => 'dtb_general',
	'settings' => 'dtb_customize_ts_particles1_color1'
)));
$wp_customize->add_setting( 'dtb_customize_ts_particles1_color2', array(
	'default' => '#BDC8D5',
	'type' => 'option',
	'sanitize_callback' => 'et_sanitize_alpha_color',
	'capability' => 'edit_theme_options'
));
$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'dtb_customize_ts_particles1_color2', array(
	'label' => __('Particles Color #2', 'divi-toolbox'),
	'section' => 'dtb_general',
	'settings' => 'dtb_customize_ts_particles1_color2'
)));
$wp_customize->add_setting( 'dtb_customize_ts_particles1_color3', array(
	'default' => '#BDC8D5',
	'type' => 'option',
	'sanitize_callback' => 'et_sanitize_alpha_color',
	'capability' => 'edit_theme_options'
));
$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'dtb_customize_ts_particles1_color3', array(
	'label' => __('Particles Color #3', 'divi-toolbox'),
	'section' => 'dtb_general',
	'settings' => 'dtb_customize_ts_particles1_color3'
)));




$wp_customize->add_setting( 'dtb_customize_ts_particles1_opacity', array(
	'default' => 0.5,
	'type'			  => 'option',
	'capability'    => 'edit_theme_options',
	'sanitize_callback' => 'wp_filter_nohtml_kses'
));
$wp_customize->add_control( new ET_Divi_Range_Option ( $wp_customize, 'dtb_customize_ts_particles1_opacity', array(
	'label' => __('Particles Opacity', 'divi-toolbox'),
	'section' => 'dtb_general',
	'type'			=> 'range',
	'input_attrs' => array(
		'min'  => 0,
		'max'  => 1,
		'step' => 0.1
	)
)));
$wp_customize->add_setting( 'dtb_customize_ts_particles1_shape', array(
	'default' => 'circle',
	'type' => 'option',
	'sanitize_callback' => 'dtb_sanitize_select',
	'capability' => 'edit_theme_options',
));

$wp_customize->add_control( 'dtb_customize_ts_particles1_shape', array(
	'label' => __('Particles Shape', 'divi-toolbox'),
	'type' => 'select',
	'section' => 'dtb_general',
	'choices' => array(
		'circle'   => 'Circle',
		'edge'      => 'Square',
		'polygon'    => 'Polygon',
		'triangle'    => 'Triangle',
		'star'   => 'Star',
		'image'   => 'Custom Image'
	)
));

$wp_customize->add_setting('dtb_customize_ts_particles1_image', array(
	'type' => 'option',
	'capability' => 'edit_theme_options',
));
$wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'dtb_customize_ts_particles1_image', array(
	'label' => __('Particle Image', 'divi-toolbox'),
	'section' => 'dtb_general',
	'settings' => 'dtb_customize_ts_particles1_image'
)));

$wp_customize->add_setting( 'dtb_customize_ts_particles1_size_min', array(
	'default' => 2,
	'type'			  => 'option',
	'capability'    => 'edit_theme_options',
	'sanitize_callback' => 'et_sanitize_int_number'
));
$wp_customize->add_control( new ET_Divi_Range_Option ( $wp_customize, 'dtb_customize_ts_particles1_size_min', array(
	'label' => __('Particles Minimum Size', 'divi-toolbox'),
	'section' => 'dtb_general',
	'type'			=> 'range',
	'input_attrs' => array(
		'min'  => 0,
		'max'  => 500,
		'step' => 1
	)
)));
$wp_customize->add_setting( 'dtb_customize_ts_particles1_size_max', array(
	'default' => 5,
	'type'			  => 'option',
	'capability'    => 'edit_theme_options',
	'sanitize_callback' => 'et_sanitize_int_number'
));
$wp_customize->add_control( new ET_Divi_Range_Option ( $wp_customize, 'dtb_customize_ts_particles1_size_max', array(
	'label' => __('Particles Max Size', 'divi-toolbox'),
	'section' => 'dtb_general',
	'type'			=> 'range',
	'input_attrs' => array(
		'min'  => 0,
		'max'  => 500,
		'step' => 1
	)
)));
$wp_customize->add_setting( 'dtb_customize_ts_particles1_speed', array(
	'default' => 2,
	'type'			  => 'option',
	'capability'    => 'edit_theme_options',
	'sanitize_callback' => 'et_sanitize_int_number'
));
$wp_customize->add_control( new ET_Divi_Range_Option ( $wp_customize, 'dtb_customize_ts_particles1_speed', array(
	'label' => __('Particles Speed', 'divi-toolbox'),
	'section' => 'dtb_general',
	'type'			=> 'range',
	'input_attrs' => array(
		'min'  => 1,
		'max'  => 10,
		'step' => 1
	)
)));
$wp_customize->add_setting( 'dtb_customize_ts_particles1_lines', array(
	'default' => 1,
	'type'			  => 'option',
	'capability'    => 'edit_theme_options',
	'sanitize_callback' => 'et_sanitize_int_number'
));
$wp_customize->add_control( new ET_Divi_Range_Option ( $wp_customize, 'dtb_customize_ts_particles1_lines', array(
	'label' => __('Lines Width', 'divi-toolbox'),
	'section' => 'dtb_general',
	'type'			=> 'range',
	'input_attrs' => array(
		'min'  => 0,
		'max'  => 20,
		'step' => 1
	)
)));
$wp_customize->add_setting( 'dtb_customize_ts_particles1_lines_color', array(
	'default' => '#000000',
	'type' => 'option',
	'sanitize_callback' => 'et_sanitize_alpha_color', 
	'capability' => 'edit_theme_options'
));
$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'dtb_customize_ts_particles1_lines_color', array(
	'label' => __('Lines Color', 'divi-toolbox'),
	'section' => 'dtb_general',
	'settings' => 'dtb_customize_ts_particles1_lines_color'
)));
$wp_customize->add_setting( 'dtb_customize_ts_particles1_lines_opacity', array(
	'default' => 0.4,
	'type'			  => 'option',
	'capability'    => 'edit_theme_options',
	'sanitize_callback' => 'wp_filter_nohtml_kses'
));
$wp_customize->add_control( new ET_Divi_Range_Option ( $wp_customize, 'dtb_customize_ts_particles1_lines_opacity', array(
	'label' => __('Lines Opacity', 'divi-toolbox'),
	'section' => 'dtb_general',
	'type'			=> 'range',
	'input_attrs' => array(
		'min'  => 0,
		'max'  => 1,
		'step' => 0.1
	)
)));
$wp_customize->add_setting( 'dtb_customize_ts_particles1_activity_hover', array(
	'default' => 'grab',
	'type' => 'option',
	'sanitize_callback' => 'dtb_sanitize_select',
	'capability' => 'edit_theme_options',
));
$wp_customize->add_control( 'dtb_customize_ts_particles1_activity_hover', array(
	'label' => __('Hover Interactivity', 'divi-toolbox'),
	'type' => 'select',
	'section' => 'dtb_general',
	'choices' => array(
		'none'   => 'None',
		'grab'      => 'Grab',
		'bubble'    => 'Bubble',
		'repulse'   => 'Repulse'
	)
));

$wp_customize->add_setting( 'dtb_modcustomize_ts_particles1_click', array(
	'default' => '',
	'sanitize_callback' => 'wp_filter_nohtml_kses'
));
$wp_customize->add_control( 'dtb_modcustomize_ts_particles1_click', array(
	'label' => __('Add more particles on click', 'divi-toolbox'),
	'type' => 'checkbox',
	'section' => 'dtb_general'
));



// #2

$wp_customize->add_setting( 'dtb_customize_title_ts_particles2', array(
	'default' => '',
	'transport' => 'refresh',
	'sanitize_callback' => 'wp_filter_nohtml_kses'
));
$wp_customize->add_control( new Toolbox_Descriptions( $wp_customize, 'dtb_customize_title_ts_particles2', array(
	'label' => __( 'Particle Background #2', 'divi-toolbox' ),
	'section' => 'dtb_general'
)));
$wp_customize->add_setting( 'dtb_customize_ts_particles2_number', array(
	'default' => 80,
	'type'			  => 'option',
	'capability'    => 'edit_theme_options',
	'sanitize_callback' => 'et_sanitize_int_number'
));
$wp_customize->add_control( new ET_Divi_Range_Option ( $wp_customize, 'dtb_customize_ts_particles2_number', array(
	'label' => __('Number of Particles', 'divi-toolbox'),
	'section' => 'dtb_general',
	'type'			=> 'range',
	'input_attrs' => array(
		'min'  => 0,
		'max'  => 300,
		'step' => 1
	)
)));
$wp_customize->add_setting( 'dtb_customize_ts_particles2_color1', array(
	'default' => '#000000',
	'type' => 'option',
	'sanitize_callback' => 'et_sanitize_alpha_color',
	'capability' => 'edit_theme_options'
));
$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'dtb_customize_ts_particles2_color1', array(
	'label' => __('Particles Color #1', 'divi-toolbox'),
	'section' => 'dtb_general',
	'settings' => 'dtb_customize_ts_particles2_color1'
)));
$wp_customize->add_setting( 'dtb_customize_ts_particles2_color2', array(
	'default' => '#BDC8D5',
	'type' => 'option',
	'sanitize_callback' => 'et_sanitize_alpha_color',
	'capability' => 'edit_theme_options'
));
$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'dtb_customize_ts_particles2_color2', array(
	'label' => __('Particles Color #2', 'divi-toolbox'),
	'section' => 'dtb_general',
	'settings' => 'dtb_customize_ts_particles2_color2'
)));
$wp_customize->add_setting( 'dtb_customize_ts_particles2_color3', array(
	'default' => '#BDC8D5',
	'type' => 'option',
	'sanitize_callback' => 'et_sanitize_alpha_color',
	'capability' => 'edit_theme_options'
));
$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'dtb_customize_ts_particles2_color3', array(
	'label' => __('Particles Color #3', 'divi-toolbox'),
	'section' => 'dtb_general',
	'settings' => 'dtb_customize_ts_particles2_color3'
)));




$wp_customize->add_setting( 'dtb_customize_ts_particles2_opacity', array(
	'default' => 0.5,
	'type'			  => 'option',
	'capability'    => 'edit_theme_options',
	'sanitize_callback' => 'wp_filter_nohtml_kses'
));
$wp_customize->add_control( new ET_Divi_Range_Option ( $wp_customize, 'dtb_customize_ts_particles2_opacity', array(
	'label' => __('Particles Opacity', 'divi-toolbox'),
	'section' => 'dtb_general',
	'type'			=> 'range',
	'input_attrs' => array(
		'min'  => 0,
		'max'  => 1,
		'step' => 0.1
	)
)));
$wp_customize->add_setting( 'dtb_customize_ts_particles2_shape', array(
	'default' => 'circle',
	'type' => 'option',
	'sanitize_callback' => 'dtb_sanitize_select',
	'capability' => 'edit_theme_options',
));

$wp_customize->add_control( 'dtb_customize_ts_particles2_shape', array(
	'label' => __('Particles Shape', 'divi-toolbox'),
	'type' => 'select',
	'section' => 'dtb_general',
	'choices' => array(
		'circle'   => 'Circle',
		'edge'      => 'Square',
		'polygon'    => 'Polygon',
		'triangle'    => 'Triangle',
		'star'   => 'Star',
		'image'   => 'Custom Image'
	)
));

$wp_customize->add_setting('dtb_customize_ts_particles2_image', array(
	'type' => 'option',
	'capability' => 'edit_theme_options',
));
$wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'dtb_customize_ts_particles2_image', array(
	'label' => __('Particle Image', 'divi-toolbox'),
	'section' => 'dtb_general',
	'settings' => 'dtb_customize_ts_particles2_image'
)));

$wp_customize->add_setting( 'dtb_customize_ts_particles2_size_min', array(
	'default' => 2,
	'type'			  => 'option',
	'capability'    => 'edit_theme_options',
	'sanitize_callback' => 'et_sanitize_int_number'
));
$wp_customize->add_control( new ET_Divi_Range_Option ( $wp_customize, 'dtb_customize_ts_particles2_size_min', array(
	'label' => __('Particles Minimum Size', 'divi-toolbox'),
	'section' => 'dtb_general',
	'type'			=> 'range',
	'input_attrs' => array(
		'min'  => 0,
		'max'  => 500,
		'step' => 1
	)
)));
$wp_customize->add_setting( 'dtb_customize_ts_particles2_size_max', array(
	'default' => 5,
	'type'			  => 'option',
	'capability'    => 'edit_theme_options',
	'sanitize_callback' => 'et_sanitize_int_number'
));
$wp_customize->add_control( new ET_Divi_Range_Option ( $wp_customize, 'dtb_customize_ts_particles2_size_max', array(
	'label' => __('Particles Max Size', 'divi-toolbox'),
	'section' => 'dtb_general',
	'type'			=> 'range',
	'input_attrs' => array(
		'min'  => 0,
		'max'  => 500,
		'step' => 1
	)
)));
$wp_customize->add_setting( 'dtb_customize_ts_particles2_speed', array(
	'default' => 2,
	'type'			  => 'option',
	'capability'    => 'edit_theme_options',
	'sanitize_callback' => 'et_sanitize_int_number'
));
$wp_customize->add_control( new ET_Divi_Range_Option ( $wp_customize, 'dtb_customize_ts_particles2_speed', array(
	'label' => __('Particles Speed', 'divi-toolbox'),
	'section' => 'dtb_general',
	'type'			=> 'range',
	'input_attrs' => array(
		'min'  => 1,
		'max'  => 10,
		'step' => 1
	)
)));
$wp_customize->add_setting( 'dtb_customize_ts_particles2_lines', array(
	'default' => 1,
	'type'			  => 'option',
	'capability'    => 'edit_theme_options',
	'sanitize_callback' => 'et_sanitize_int_number'
));
$wp_customize->add_control( new ET_Divi_Range_Option ( $wp_customize, 'dtb_customize_ts_particles2_lines', array(
	'label' => __('Lines Width', 'divi-toolbox'),
	'section' => 'dtb_general',
	'type'			=> 'range',
	'input_attrs' => array(
		'min'  => 0,
		'max'  => 20,
		'step' => 1
	)
)));
$wp_customize->add_setting( 'dtb_customize_ts_particles2_lines_color', array(
	'default' => '#000000',
	'type' => 'option',
	'sanitize_callback' => 'et_sanitize_alpha_color', 
	'capability' => 'edit_theme_options'
));
$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'dtb_customize_ts_particles2_lines_color', array(
	'label' => __('Lines Color', 'divi-toolbox'),
	'section' => 'dtb_general',
	'settings' => 'dtb_customize_ts_particles2_lines_color'
)));
$wp_customize->add_setting( 'dtb_customize_ts_particles2_lines_opacity', array(
	'default' => 0.4,
	'type'			  => 'option',
	'capability'    => 'edit_theme_options',
	'sanitize_callback' => 'wp_filter_nohtml_kses'
));
$wp_customize->add_control( new ET_Divi_Range_Option ( $wp_customize, 'dtb_customize_ts_particles2_lines_opacity', array(
	'label' => __('Lines Opacity', 'divi-toolbox'),
	'section' => 'dtb_general',
	'type'			=> 'range',
	'input_attrs' => array(
		'min'  => 0,
		'max'  => 1,
		'step' => 0.1
	)
)));
$wp_customize->add_setting( 'dtb_customize_ts_particles2_activity_hover', array(
	'default' => 'grab',
	'type' => 'option',
	'sanitize_callback' => 'dtb_sanitize_select',
	'capability' => 'edit_theme_options',
));
$wp_customize->add_control( 'dtb_customize_ts_particles2_activity_hover', array(
	'label' => __('Hover Interactivity', 'divi-toolbox'),
	'type' => 'select',
	'section' => 'dtb_general',
	'choices' => array(
		'none'   => 'None',
		'grab'      => 'Grab',
		'bubble'    => 'Bubble',
		'repulse'   => 'Repulse'
	)
));

$wp_customize->add_setting( 'dtb_modcustomize_ts_particles2_click', array(
	'default' => '',
	'sanitize_callback' => 'wp_filter_nohtml_kses'
));
$wp_customize->add_control( 'dtb_modcustomize_ts_particles2_click', array(
	'label' => __('Add more particles on click', 'divi-toolbox'),
	'type' => 'checkbox',
	'section' => 'dtb_general'
));

