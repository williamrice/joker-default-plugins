<?php
$dtb_particles2_container_val = dtb_get_option('dtb_particles2_container');

$dtb_overlay_blur_val = dtb_get_option('dtb_overlay_blur');
$dtb_overlay_hide_val = dtb_get_option('dtb_overlay_hide');
$overlay_bg = get_option('dtb_customize_overlay_bg', 'rgba(255,255,255,0.8)');
$overlay_close = get_option('dtb_customize_overlay_close', '#000000');
$overlay_close_bg = get_option('dtb_customize_overlay_close_bg', '#fff');


?>


#moving-bg1 canvas, #moving-bg2 canvas {
	position:absolute;
	top:0;
	left:0;
	bottom:0;
	z-index:1;
	display:block;
}


<?php if ($dtb_particles2_container_val !== '') { ?>

div.et_pb_section, #main-content {
	background-color:transparent;	
}
.dsm-popup .et_pb_section {
	background:#fff;
}
#page-container canvas {
	position:absolute;
	top:0;
	left:0;
	bottom:0;
	z-index:1;
	display:block;
}
#page-container {
	position:relative;
}
#et-main-area {
	z-index: 2;
	position: relative;
}

<?php } ?>