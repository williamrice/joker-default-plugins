<?php
	
	$dtb_sticky_toolbar = dtb_get_option('dtb_sticky_toolbar');
?>

<?php if ($dtb_sticky_toolbar =='1') { ?>
.et-fb-option-container .mce-panel .mce-top-part {
	position: sticky!important;
	top: -60px;
}
<?php }