<?php
$dtb_enable_overlay_val = dtb_get_option('dtb_enable_overlay');
$dtb_overlay_blur_val = dtb_get_option('dtb_overlay_blur');
$dtb_overlay_hide_val = dtb_get_option('dtb_overlay_hide');
$overlay_bg = get_option('dtb_customize_overlay_bg', 'rgba(255,255,255,0.8)');
$overlay_close = get_option('dtb_customize_overlay_close', '#000000');
$overlay_close_bg = get_option('dtb_customize_overlay_close_bg', '#fff');
$overlay_close_hover = get_option('dtb_customize_overlay_close_hover', '#fff');
$overlay_close_bg_hover = get_option('dtb_customize_overlay_close_bg_hover', '#000000');


$overlay_icon_border = get_option('dtb_customize_overlay_icon_border', '2');
$overlay_icon_thick = get_option('dtb_customize_overlay_icon_thick', '2');
$overlay_button_right = get_option('dtb_customize_overlay_button_right', '15');
$overlay_button_top = get_option('dtb_customize_overlay_button_top', '15');
$overlay_button_border = get_option('dtb_customize_overlay_button_border', '3');
$overlay_icon_size = get_option('dtb_customize_overlay_icon_size', '40');




if ($dtb_enable_overlay_val !== '') { ?>

.dtb-default-close {
	position: fixed;
	top: <?php echo esc_html($overlay_button_top); ?>px;
	right: <?php echo esc_html($overlay_button_right); ?>px;
	z-index: 3;
	width: <?php echo esc_html($overlay_icon_size); ?>px;
	height: <?php echo esc_html($overlay_icon_size); ?>px;
	background-size: cover;
	cursor: pointer;
	display: block;
	background:<?php echo esc_html($overlay_close_bg); ?>;
	border-radius:<?php echo esc_html($overlay_button_border); ?>px;
}

.dtb-default-close:hover {
	background: <?php echo esc_html($overlay_close_bg_hover); ?>;
}
.dtb-close {
	cursor: pointer;
}

.dtb-default-close::before, .dtb-default-close::after {
	content: '';
	display: block;
	width: calc(100% - 10px);
	height: <?php echo esc_html($overlay_icon_thick); ?>px;
	transform: rotate(45deg);
	border-radius: 0;
	transform-origin: center;
	position: absolute;
	bottom: calc(50% - <?php echo esc_html(($overlay_icon_thick/2)); ?>px);
	left:5px;
	background:<?php echo esc_html($overlay_close); ?>;
	border-radius:<?php echo esc_html($overlay_icon_border); ?>px;
}
.dtb-default-close:hover::before, .dtb-default-close:hover::after {
	background:<?php echo esc_html($overlay_close_hover); ?>;
}

.dtb-default-close::after {
	transform: rotate(-45deg);
}


body:not(.et-fb) .dtb-overlay-wrapper {
	position: fixed !important;
	display: none;
	z-index: 200100;
	top: 0;
	right: 0;
	bottom: 0;
	left: 0;
	height: 100vh;
	background: <?php echo esc_html($overlay_bg); ?>;
}

body.admin-bar:not(.et-fb) .dtb-overlay-wrapper {
	top: 32px;
	height: calc(100vh - 32px);
}

body:not(.et-fb) .dtb-overlay-wrapper .dtb-inner-wrapper {
	overflow-y: scroll;
	height: 100%;
	width: 100%;
	position: relative;
}

body:not(.et-fb) .dtb-overlay-wrapper .dtb-inner-wrapper>div {
	min-height: 100%;
	display: flex;
	flex-direction: column;
	justify-content: center;
}

body:not(.et-fb) .dtb-overlay-wrapper.is-visible .dtb-inner-wrapper {
	animation: dtb-show-it .6s cubic-bezier(.25, .46, .45, .94) .5s both;
}
@keyframes dtb-show-it{0%{transform:translateY(70px);opacity:0}100%{transform:translateY(0);opacity:1}}

body:not(.et-fb) .dtb-overlay-wrapper.is-visible [class*=dtb-overlay-] {
	display: block;
}

.et_builder_inner_content.is-visible {
	z-index: 300001!important;
	transition: all .6s;
}



body.et-fb.et-db #et-boc .et-l .builder-hidden {
	display: none !important;
}

body.stopscroll {
	overflow: hidden;
}

[class*=dtb-show] {
	cursor:pointer;
}

<?php if ( $dtb_overlay_hide_val === '1') { ?>
	body.et-fb.et-db #et-boc .et-l [class*='dtb-overlay'] {display: none !important;}
<?php } if ( $dtb_overlay_blur_val === '1') { ?>
	.dtb-overlay-wrapper {backdrop-filter:blur(3px); -webkit-backdrop-filter:blur(3px);}
<?php } ?>


<?php }