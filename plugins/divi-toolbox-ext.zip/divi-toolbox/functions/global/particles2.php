<?php

function dtb_particles2_scripts() {
	if (function_exists('et_core_is_fb_enabled') && (!et_core_is_fb_enabled())) {
		wp_dequeue_script( 'dtb-particles-bg');
		wp_enqueue_script('dtb-ts-particles', DTB_TOOLBOX_PLUGIN_URI.
			'/assets/js/ts-particles.js', array('jquery'), '', true);
	}
	wp_localize_script('dtb-ts-particles', 'dtb', array(
		
		'particles_container' => dtb_get_option('dtb_particles2_container'),
		
		'ts_particles1_number' => get_option('dtb_customize_ts_particles1_number', '80'),
		'ts_particles1_color1' => get_option('dtb_customize_ts_particles1_color1', '#000000'),
		'ts_particles1_color2' => get_option('dtb_customize_ts_particles1_color2', '#BDC8D5'),
		'ts_particles1_color3' => get_option('dtb_customize_ts_particles1_color3', '#BDC8D5'),
		'ts_particles1_opacity' => get_option('dtb_customize_ts_particles1_opacity', '0.5'),
		'ts_particles1_shape' => get_option('dtb_customize_ts_particles1_shape', 'circle'),
		'ts_particles1_image' => get_option('dtb_customize_ts_particles1_image', ''),
		'ts_particles1_size_min' => get_option('dtb_customize_ts_particles1_size_min', '2'),
		'ts_particles1_size_max' => get_option('dtb_customize_ts_particles1_size_max', '5'),
		'ts_particles1_speed' => get_option('dtb_customize_ts_particles1_speed', '2'),
		'ts_particles1_lines' => get_option('dtb_customize_ts_particles1_lines', '1'),
		'ts_particles1_lines_color' => get_option('dtb_customize_ts_particles1_lines_color', '#000000'),
		'ts_particles1_lines_opacity' => get_option('dtb_customize_ts_particles1_lines_opacity', '0.4'),
		'ts_particles1_activity_hover' => get_option('dtb_customize_ts_particles1_activity_hover', 'grab'),
		'ts_particles1_click' => get_theme_mod('dtb_modcustomize_ts_particles1_click', ''),
		
		'ts_particles2_number' => get_option('dtb_customize_ts_particles2_number', '80'),
		'ts_particles2_color1' => get_option('dtb_customize_ts_particles2_color1', '#000000'),
		'ts_particles2_color2' => get_option('dtb_customize_ts_particles2_color2', '#BDC8D5'),
		'ts_particles2_color3' => get_option('dtb_customize_ts_particles2_color3', '#BDC8D5'),
		'ts_particles2_opacity' => get_option('dtb_customize_ts_particles2_opacity', '0.5'),
		'ts_particles2_shape' => get_option('dtb_customize_ts_particles2_shape', 'circle'),
		'ts_particles2_image' => get_option('dtb_customize_ts_particles2_image', ''),
		'ts_particles2_size_min' => get_option('dtb_customize_ts_particles2_size_min', '2'),
		'ts_particles2_size_max' => get_option('dtb_customize_ts_particles2_size_max', '5'),
		'ts_particles2_speed' => get_option('dtb_customize_ts_particles2_speed', '2'),
		'ts_particles2_lines' => get_option('dtb_customize_ts_particles2_lines', '1'),
		'ts_particles2_lines_color' => get_option('dtb_customize_ts_particles2_lines_color', '#000000'),
		'ts_particles2_lines_opacity' => get_option('dtb_customize_ts_particles2_lines_opacity', '0.4'),
		'ts_particles2_activity_hover' => get_option('dtb_customize_ts_particles2_activity_hover', 'grab'),
		'ts_particles2_click' => get_theme_mod('dtb_modcustomize_ts_particles2_click', '')
	));
}
add_action('wp_enqueue_scripts', 'dtb_particles2_scripts');