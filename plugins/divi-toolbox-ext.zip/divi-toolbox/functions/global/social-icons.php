<?php

function dtb_inline_fa_style() {
	
	
	
	$divi_dynamic_css = et_get_option('divi_dynamic_css');
	if (($divi_dynamic_css !== '') && ($divi_dynamic_css !== '0') && ($divi_dynamic_css !== 'false')) { ?>
	
	<style id="dtb-inline-icon-font">@font-face{font-family:FontAwesome;font-style:normal;font-weight:400;font-display:block;src:url("<?php echo get_template_directory_uri(); ?>/core/admin/fonts/fontawesome/fa-brands-400.eot");src:url("<?php echo get_template_directory_uri(); ?>/core/admin/fonts/fontawesome/fa-brands-400.eot?#iefix") format("embedded-opentype"),url("<?php echo get_template_directory_uri(); ?>/core/admin/fonts/fontawesome/fa-brands-400.woff2") format("woff2"),url("<?php echo get_template_directory_uri(); ?>/core/admin/fonts/fontawesome/fa-brands-400.woff") format("woff"),url("<?php echo get_template_directory_uri(); ?>/core/admin/fonts/fontawesome/fa-brands-400.ttf") format("truetype"),url("<?php echo get_template_directory_uri(); ?>/core/admin/fonts/fontawesome/fa-brands-400.svg#fontawesome") format("svg")}
	.et-social-telegram a.icon:before{content:"\F3FE"}.et-social-amazon a.icon:before{content:"\F270"}.et-social-bandcamp a.icon:before{content:"\F2D5"}.et-social-bitbucket a.icon:before{content:"\F171"}.et-social-behance a.icon:before{content:"\F1B4"}.et-social-buffer a.icon:before{content:"\F837"}.et-social-codepen a.icon:before{content:"\F1CB"}.et-social-deviantart a.icon:before{content:"\F1BD"}.et-social-flipboard a.icon:before{content:"\F44D"}.et-social-foursquare a.icon:before{content:"\F180"}.et-social-github a.icon:before{content:"\F09B"}.et-social-goodreads a.icon:before{content:"\F3A9"}.et-social-google a.icon:before{content:"\F1A0"}.et-social-houzz a.icon:before{content:"\F27C"}.et-social-itunes a.icon:before{content:"\F3B5"}.et-social-last_fm a.icon:before{content:"\F202"}.et-social-line a.icon:before{content:"\F3C0"}.et-social-medium a.icon:before,.et-social-meetup a.icon:before{content:"\F3C7"}.et-social-odnoklassniki a.icon:before{content:"\F263"}.et-social-patreon a.icon:before{content:"\F3D9"}.et-social-periscope a.icon:before{content:"\F3DA"}.et-social-quora a.icon:before{content:"\F2C4"}.et-social-researchgate a.icon:before{content:"\F4F8"}.et-social-reddit a.icon:before{content:"\F281"}.et-social-snapchat a.icon:before{content:"\F2AC"}.et-social-soundcloud a.icon:before{content:"\F1BE"}.et-social-spotify a.icon:before{content:"\F1BC"}.et-social-steam a.icon:before{content:"\F3F6"}.et-social-tripadvisor a.icon:before{content:"\F262"}.et-social-tiktok a.icon:before{content:"\E07B"}.et-social-twitch a.icon:before{content:"\F1E8"}.et-social-vk a.icon:before{content:"\F189"}.et-social-weibo a.icon:before{content:"\F18A"}.et-social-whatsapp a.icon:before{content:"\F232"}.et-social-xing a.icon:before{content:"\F168"}.et-social-yelp a.icon:before{content:"\F1E9"}.et-social-vimeo a.icon:before{content:"\f27d";font-family:FontAwesome!important}.et-social-dribble a.icon:before{content:"\f17d";font-family:FontAwesome!important}.et-social-flickr a.icon:before{content:"\f16e";font-family:FontAwesome!important}.et-social-tumblr a.icon:before{content:"\f173";font-family:FontAwesome!important}.et-social-pinterest a.icon:before{content:"\f231";font-family:FontAwesome!important}.et-social-linkedin a.icon:before{content:"\f0e1";font-family:FontAwesome!important}.et-social-youtube a.icon:before{content:"\f167";font-family:FontAwesome!important}.et-social-skype a.icon:before{content:"\f17e";font-family:FontAwesome!important}
	
	

	</style>	
	<?php } 
}
add_action('wp_footer', 'dtb_inline_fa_style');



function dtb_social_icons_scripts() {
	if (function_exists('et_core_is_fb_enabled') && (!et_core_is_fb_enabled())) {
		wp_enqueue_script('dtb-social-icons', DTB_TOOLBOX_PLUGIN_URI.
			'/assets/js/more-social-icons.js', array('jquery'), '', true);
	}
	wp_localize_script('dtb-social-icons', 'url_values', array(
		'dtb_social_links' => dtb_get_option('dtb_social_links'),
		'dtb_instagram_url' => dtb_get_option('dtb_instagram_url'),
		'dtb_youtube_url' => dtb_get_option('dtb_youtube_url'),
		'dtb_linkedin_url' => dtb_get_option('dtb_linkedin_url'),
		'dtb_pinterest_url' => dtb_get_option('dtb_pinterest_url'),
		'dtb_tumblr_url' => dtb_get_option('dtb_tumblr_url'),
		'dtb_flickr_url' => dtb_get_option('dtb_flickr_url'),
		'dtb_dribble_url' => dtb_get_option('dtb_dribble_url'),
		'dtb_vimeo_url' => dtb_get_option('dtb_vimeo_url'),
		'dtb_skype_url' => dtb_get_option('dtb_skype_url'),
		'dtb_amazon_url' => dtb_get_option('dtb_amazon_url'),
		'dtb_bitbucket_url' => dtb_get_option('dtb_bitbucket_url'),
		'dtb_behance_url' => dtb_get_option('dtb_behance_url'),
		'dtb_etsy_url' => dtb_get_option('dtb_etsy_url'),
		'dtb_foursquare_url' => dtb_get_option('dtb_foursquare_url'),
		'dtb_github_url' => dtb_get_option('dtb_github_url'),
		'dtb_itunes_url' => dtb_get_option('dtb_itunes_url'),
		'dtb_patreon_url' => dtb_get_option('dtb_patreon_url'),
		'dtb_reddit_url' => dtb_get_option('dtb_reddit_url'),
		'dtb_slack_url' => dtb_get_option('dtb_slack_url'),
		'dtb_strava_url' => dtb_get_option('dtb_strava_url'),
		'dtb_snapchat_url' => dtb_get_option('dtb_snapchat_url'),
		'dtb_soundcloud_url' => dtb_get_option('dtb_soundcloud_url'),
		'dtb_spotify_url' => dtb_get_option('dtb_spotify_url'),
		'dtb_telegram_url' => dtb_get_option('dtb_telegram_url'),
		'dtb_tripadvisor_url' => dtb_get_option('dtb_tripadvisor_url'),
		'dtb_tiktok_url' => dtb_get_option('dtb_tiktok_url'),
		'dtb_twitch_url' => dtb_get_option('dtb_twitch_url'),
		'dtb_whatsapp_url' => dtb_get_option('dtb_whatsapp_url'),
		'dtb_yelp_url' => dtb_get_option('dtb_yelp_url'),
		'dtb_codepen_url' => dtb_get_option('dtb_codepen_url'),
		'dtb_fb_messanger_url' => dtb_get_option('dtb_fb_messanger_url'),
	));
}
add_action('wp_enqueue_scripts', 'dtb_social_icons_scripts');