<?php
function dtb_overlay_scripts() {
	if (function_exists('et_core_is_fb_enabled') && (!et_core_is_fb_enabled())) {
		wp_enqueue_script('dtb-overlays', DTB_TOOLBOX_PLUGIN_URI.
			'/assets/js/overlays.js', array('jquery'), '', true);
	}
	wp_localize_script('dtb-overlays', 'overlay_values', array(
		'dtb_overlay_blur' => dtb_get_option('dtb_overlay_blur'),
		'dtb_overlay_close_click' => dtb_get_option('dtb_overlay_close_click'),
		'dtb_overlay_close_esc' => dtb_get_option('dtb_overlay_close_esc'),
		'dtb_overlay_hide' => dtb_get_option('dtb_overlay_hide')
	));
}
add_action('wp_enqueue_scripts', 'dtb_overlay_scripts', 100);