<?php

/* Custom Font Types Support */
add_filter('et_pb_supported_font_formats', 'dtb_custom_font_formats', 1);

function dtb_custom_font_formats() { 
    return array('otf', 'ttf', 'woff', 'woff2');
}