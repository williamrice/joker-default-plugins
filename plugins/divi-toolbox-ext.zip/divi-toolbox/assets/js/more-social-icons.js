
jQuery(document).ready(function ($) {
	if (url_values.dtb_social_links === '1') {
		if (url_values.dtb_fb_messanger_url !== '') {
			$('.et-social-icons').append('<li class="et-social-icon et-pb-social-fa-icon et-social-fb_messanger"><a href="' + url_values.dtb_fb_messanger_url + '" class="icon"><span>Facebook Messanger</span></a></li>')
		}
		if (url_values.dtb_skype_url !== '') {
			$('.et-social-icons').append('<li class="et-social-icon et-social-skype"><a href="' + url_values.dtb_skype_url + '" class="icon"><span>Skype</span></a></li>')
		}
		if (url_values.dtb_instagram_url !== '') {
			$('.et-social-icons').append('<li class="et-social-icon et-social-instagram"><a href="' + url_values.dtb_instagram_url + '" class="icon"><span>Instagram</span></a></li>')
		}
		if (url_values.dtb_youtube_url !== '') {
			$('.et-social-icons').append('<li class="et-social-icon et-social-youtube"><a href="' + url_values.dtb_youtube_url + '" class="icon"><span>YouTube</span></a></li>')
		}
		if (url_values.dtb_linkedin_url !== '') {
			$('.et-social-icons').append('<li class="et-social-icon et-social-linkedin"><a href="' + url_values.dtb_linkedin_url + '" class="icon"><span>LinkedIn</span></a></li>')
		}
		if (url_values.dtb_pinterest_url !== '') {
			$('.et-social-icons').append('<li class="et-social-icon et-social-pinterest"><a href="' + url_values.dtb_pinterest_url + '" class="icon"><span>Pinterest</span></a></li>')
		}
		if (url_values.dtb_tumblr_url !== '') {
			$('.et-social-icons').append('<li class="et-social-icon et-social-tumblr"><a href="' + url_values.dtb_tumblr_url + '" class="icon"><span>Tumblr</span></a></li>')
		}
		if (url_values.dtb_flickr_url !== '') {
			$('.et-social-icons').append('<li class="et-social-icon et-social-flickr"><a href="' + url_values.dtb_flickr_url + '" class="icon"><span>Flickr</span></a></li>')
		}
		if (url_values.dtb_dribble_url !== '') {
			$('.et-social-icons').append('<li class="et-social-icon et-social-dribble"><a href="' + url_values.dtb_dribble_url + '" class="icon"><span>Dribble</span></a></li>')
		}
		if (url_values.dtb_vimeo_url !== '') {
			$('.et-social-icons').append('<li class="et-social-icon et-social-vimeo"><a href="' + url_values.dtb_vimeo_url + '" class="icon"><span>Vimeo</span></a></li>')
		}
		if (url_values.dtb_amazon_url !== '') {
			$('.et-social-icons').append('<li class="et-social-icon et-pb-social-fa-icon et-social-amazon"><a href="' + url_values.dtb_amazon_url + '" class="icon"><span>Amazon</span></a></li>')
		}
		if (url_values.dtb_bitbucket_url !== '') {
			$('.et-social-icons').append('<li class="et-social-icon et-pb-social-fa-icon et-social-bitbucket"><a href="' + url_values.dtb_bitbucket_url + '" class="icon"><span>Bitbucket</span></a></li>')
		}
		if (url_values.dtb_behance_url !== '') {
			$('.et-social-icons').append('<li class="et-social-icon et-pb-social-fa-icon et-social-behance"><a href="' + url_values.dtb_behance_url + '" class="icon"><span>Behance</span></a></li>')
		}
		if (url_values.dtb_codepen_url !== '') {
			$('.et-social-icons').append('<li class="et-social-icon et-pb-social-fa-icon et-social-codepen"><a href="' + url_values.dtb_codepen_url + '" class="icon"><span>Codepen</span></a></li>')
		}
		if (url_values.dtb_etsy_url !== '') {
			$('.et-social-icons').append('<li class="et-social-icon et-pb-social-fa-icon et-social-etsy"><a href="' + url_values.dtb_etsy_url + '" class="icon"><span>Etsy</span></a></li>')
		}
		if (url_values.dtb_foursquare_url !== '') {
			$('.et-social-icons').append('<li class="et-social-icon et-pb-social-fa-icon et-social-foursquare"><a href="' + url_values.dtb_foursquare_url + '" class="icon"><span>Foursquare</span></a></li>')
		}
		if (url_values.dtb_github_url !== '') {
			$('.et-social-icons').append('<li class="et-social-icon et-pb-social-fa-icon et-social-github"><a href="' + url_values.dtb_github_url + '" class="icon"><span>Github</span></a></li>')
		}
		if (url_values.dtb_itunes_url !== '') {
			$('.et-social-icons').append('<li class="et-social-icon et-pb-social-fa-icon et-social-itunes"><a href="' + url_values.dtb_itunes_url + '" class="icon"><span>iTunes</span></a></li>')
		}
		if (url_values.dtb_patreon_url !== '') {
			$('.et-social-icons').append('<li class="et-social-icon et-pb-social-fa-icon et-social-patreon"><a href="' + url_values.dtb_patreon_url + '" class="icon"><span>Patreon</span></a></li>')
		}
		if (url_values.dtb_reddit_url !== '') {
			$('.et-social-icons').append('<li class="et-social-icon et-pb-social-fa-icon et-social-reddit"><a href="' + url_values.dtb_reddit_url + '" class="icon"><span>Reddit</span></a></li>')
		}
		if (url_values.dtb_slack_url !== '') {
			$('.et-social-icons').append('<li class="et-social-icon et-pb-social-fa-icon et-social-slack"><a href="' + url_values.dtb_slack_url + '" class="icon"><span>Slack</span></a></li>')
		}
		if (url_values.dtb_snapchat_url !== '') {
			$('.et-social-icons').append('<li class="et-social-icon et-pb-social-fa-icon et-social-snapchat"><a href="' + url_values.dtb_snapchat_url + '" class="icon"><span>Snapchat</span></a></li>')
		}
		if (url_values.dtb_soundcloud_url !== '') {
			$('.et-social-icons').append('<li class="et-social-icon et-pb-social-fa-icon et-social-soundcloud"><a href="' + url_values.dtb_soundcloud_url + '" class="icon"><span>Soundcloud</span></a></li>')
		}
		if (url_values.dtb_spotify_url !== '') {
			$('.et-social-icons').append('<li class="et-social-icon et-pb-social-fa-icon et-social-spotify"><a href="' + url_values.dtb_spotify_url + '" class="icon"><span>Spotify</span></a></li>')
		}
		if (url_values.dtb_strava_url !== '') {
			$('.et-social-icons').append('<li class="et-social-icon et-pb-social-fa-icon et-social-strava"><a href="' + url_values.dtb_strava_url + '" class="icon"><span>Strava</span></a></li>')
		}
		if (url_values.dtb_telegram_url !== '') {
			$('.et-social-icons').append('<li class="et-social-icon et-pb-social-fa-icon et-social-telegram"><a href="' + url_values.dtb_telegram_url + '" class="icon"><span>Telegram</span></a></li>')
		}
		if (url_values.dtb_tripadvisor_url !== '') {
			$('.et-social-icons').append('<li class="et-social-icon et-pb-social-fa-icon et-social-tripadvisor"><a href="' + url_values.dtb_tripadvisor_url + '" class="icon"><span>Tripadvisor</span></a></li>')
		}
		if (url_values.dtb_tiktok_url !== '') {
			$('.et-social-icons').append('<li class="et-social-icon et-pb-social-fa-icon et-social-tiktok"><a href="' + url_values.dtb_tiktok_url + '" class="icon"><span>Tiktok</span></a></li>')
		}
		if (url_values.dtb_twitch_url !== '') {
			$('.et-social-icons').append('<li class="et-social-icon et-pb-social-fa-icon et-social-twitch"><a href="' + url_values.dtb_twitch_url + '" class="icon"><span>Twitch</span></a></li>')
		}
		if (url_values.dtb_whatsapp_url !== '') {
			$('.et-social-icons').append('<li class="et-social-icon et-pb-social-fa-icon et-social-whatsapp"><a href="' + url_values.dtb_whatsapp_url + '" class="icon"><span>Whatsapp</span></a></li>')
		}
		if (url_values.dtb_yelp_url !== '') {
			$('.et-social-icons').append('<li class="et-social-icon et-pb-social-fa-icon et-social-yelp"><a href="' + url_values.dtb_yelp_url + '" class="icon"><span>Yelp</span></a></li>')
		}
	}
})