<?php 

function dtb_toolbox_backend_style(){
	$dtb_sticky_toolbar = dtb_get_option('dtb_sticky_toolbar');
	if ($dtb_sticky_toolbar =='1') { ?>
	<style id="dtb-toolbox-backend-style">
		.et-fb-option-container .mce-panel .mce-top-part {
			position: sticky!important;
			top: -60px;
		}
	</style>

	<?php }
}
add_action('admin_footer', 'dtb_toolbox_backend_style');

?>