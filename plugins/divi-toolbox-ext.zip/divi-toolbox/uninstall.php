<?php

if (!defined('WP_UNINSTALL_PLUGIN')) exit;
if (!current_user_can('manage_options')) exit;

// Check Toolbox settings
if ( ! function_exists( 'dtb_get_option' ) ) {
	function dtb_get_option( $dtb_option_name, $dtb_default_value = ''){
		$dtb_option_value = '';
		$dtb_toolbox_setting = maybe_unserialize( get_option( 'dtb_toolbox' ) );
		if ( $dtb_option_name != '' && is_array( $dtb_toolbox_setting ) && array_key_exists( $dtb_option_name,$dtb_toolbox_setting ) ){
			$dtb_option_value = $dtb_toolbox_setting[ $dtb_option_name ];
			if ( $dtb_option_value == '' && $dtb_default_value!= ''  ){
				$dtb_option_value = $dtb_default_value;
			}
		}
		return $dtb_option_value;
	}
}
// Check if user wants to remove plugin data 
$dtb_uninstall_data_val = dtb_get_option('dtb_uninstall_data');
if ($dtb_uninstall_data_val == '1' ){
	foreach (wp_load_alloptions() as $option => $value) {
		if (strpos($option, 'dtb_customize_') !== false) {
			delete_option($option);
		}
	}
	delete_option('dtb_toolbox');
	delete_option('dtbchange_v1_2');
}
